package com.example.sharebite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SharebiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(SharebiteApplication.class, args);
	}

}
