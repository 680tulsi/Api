package com.example.sharebite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharebiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
